let balance = 1000;

function placeBet(color) {
    const betAmount = parseInt(document.getElementById('betAmount').value);

    if (betAmount > balance) {
        document.getElementById('result').innerText = "Недостаточно средств для ставки.";
        return;
    }

    balance -= betAmount;

    // Симуляция вращения рулетки
    const resultColor = Math.random() < 0.5 ? 'red' : 'black';
    animateWheel(resultColor);

    setTimeout(() => {
        if (color === resultColor) {
            const winnings = betAmount * 2;
            balance += winnings;
            document.getElementById('result').innerText = `Выпало ${resultColor}! Вы выиграли ${winnings} монет.`;
        } else {
            document.getElementById('result').innerText = `Выпало ${resultColor}. Вы проиграли ${betAmount} монет.`;
        }

        document.getElementById('balance').innerText = balance;
    }, 1000);
}

function animateWheel(color) {
    const wheel = document.querySelector('.wheel');

    // Сбрасываем текущую анимацию
    wheel.style.transition = 'none';
    wheel.style.transform = 'rotate(0deg)';

    // Даем небольшую задержку перед началом новой анимации
    setTimeout(() => {
        const randomDegree = Math.floor(Math.random() * 360) + 360; // вращаем на случайное количество градусов
        wheel.style.transition = 'transform 1s ease-out';
        wheel.style.transform = `rotate(${randomDegree}deg)`;
    }, 10);  // Небольшая задержка в 50 миллисекунд
}
